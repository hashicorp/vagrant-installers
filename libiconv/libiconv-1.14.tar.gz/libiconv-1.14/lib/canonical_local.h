  (int)(long)&((struct stringpool_t *)0)->stringpool_str271,
  (int)(long)&((struct stringpool_t *)0)->stringpool_str664,
