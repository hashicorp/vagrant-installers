  S(osf1_0, "DEC-KANJI", ei_dec_kanji )
  S(osf1_1, "DEC-HANYU", ei_dec_hanyu )
